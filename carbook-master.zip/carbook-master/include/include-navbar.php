<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	<div class="container">
		<a class="navbar-brand" href="index.php">Car<span>Book</span></a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="oi oi-menu"></span> Menu
		</button>

		<div class="collapse navbar-collapse" id="ftco-nav">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item"><a href="index.php" class="nav-link"><b>Anasayfa</b></a></li>
				<li class="nav-item"><a href="about.php" class="nav-link">Hakkımızda</a></li>
				<li class="nav-item "><a href="services.php" class="nav-link">Hizmetlerimiz</a></li>
				<li class="nav-item "><a href="car.php" class="nav-link">Arabalar</a></li>
				<li class="nav-item "><a href="contact.php" class="nav-link">İletişim</a></li>
				<li class="nav-item"><a href="admin/index.php" class="nav-link">Admin</a></li>
			</ul>
		</div>
	</div>
</nav>