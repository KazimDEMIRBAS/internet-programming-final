<?php include 'db/connection.php';
 $cek=$conn->prepare("SELECT * FROM `hakkimizda` ORDER BY `id` DESC LIMIT 1");
 $cek->execute();
 $row=$cek->fetch(PDO::FETCH_ASSOC);
 ?>
 <section class="ftco-section ftco-about">
    <div class="container">
        <div class="row no-gutters">
            <div class="col-md-6 p-md-5 img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/about.jpg);">
            </div>
            <div class="col-md-6 wrap-about ftco-animate">
                <div class="heading-section heading-section-white pl-md-5">
                    <span class="subheading">About us</span>
                    <h2 class="mb-4"><?= $row["baslik"]?></h2>

                    <p><?= $row["govde"]?></p>
                </div>
            </div>
        </div>
    </div>
</section>