    <?php include_once 'include/include-head.php'; ?>
 <body>
    
    <?php include_once 'include/include-navbar.php';
    $page = "Anasayfa";
    ?>
    <!-- END nav -->
    
    <div class="hero-wrap ftco-degree-bg" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text justify-content-start align-items-center justify-content-center">
          <div class="col-lg-8 ftco-animate">
          	<div class="text w-100 text-center mb-md-5 pb-md-5">
	            <h1 class="mb-4">Hızlı &amp; Kolay Araç Kiralama</h1>
	            <p style="font-size: 18px;">A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts</p>
	            <a href="https://vimeo.com/45830194" class="icon-wrap popup-vimeo d-flex align-items-center mt-4 justify-content-center">
	            	<div class="icon d-flex align-items-center justify-content-center">
	            		<span class="ion-ios-play"></span>
	            	</div>
	            	<div class="heading-title ml-5">
		            	<span>Araç kiralamanın kolay yolu</span>
	            	</div>
	            </a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <?php include_once 'include/include-whatweoffer.php'; ?>

    <?php include_once 'include/include-about.php'; ?>

		<?php include_once 'include/include-services.php'; ?>

		<?php include_once 'include/include-becomeDriver.php'; ?>

    <?php include_once 'include/include-happyClient.php'; ?>

    <?php include_once 'include/include-count.php'; ?>

    <?php include_once 'include/include-footer.php'; ?>
    
    <?php include_once 'include/include-loader.php'; ?>
  </body>
  </html>
