<?php include_once 'include/include-head.php'; ?>
  <body>
    
  <?php include_once 'include/include-navbar.php';
  
  ?>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-5">
          	<p class="breadcrumbs"><span class="mr-2"><a href="index.php">Anasayfa <i class="ion-ios-arrow-forward"></i></a></span> <span>Hakkımızda<i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-3 bread">Hakkımızda</h1>
          </div>
        </div>
      </div>
    </section>

    <?php include_once 'include/include-about.php';?>

		<?php include_once 'include/include-becomeDriver.php'; ?>


    <?php include_once 'include/include-happyClient.php'; ?>

    <?php include_once 'include/include-count.php'; ?>

    <?php include_once 'include/include-footer.php'; ?>
    
  

  <!-- loader -->
  <?php include_once 'include/include-loader.php'; ?>
    
  </body>
</html>