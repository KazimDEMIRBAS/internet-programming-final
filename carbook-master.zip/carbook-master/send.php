<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpMailer/src/Exception.php';
require 'phpMailer/src/PHPMailer.php';
require 'phpMailer/src/SMTP.php';

if(isset($_POST["send"])){
    $mail = new PHPMailer(true);

    $mail -> isSMTP();
    $mail -> Host = 'smtp.gmail.com';
    $mail -> SMTPAuth = true;
    $mail -> Username = 'kazimdemirbasphpmailer@gmail.com';
    $mail -> Password = 'ldzwotwdiiyergwj';
    $mail -> SMTPSecure = 'ssl';
    $mail -> Port = 465;

    $mail -> setFrom('kazimdemirbasphpmailer@gmail.com');
    $mail -> addAddress($_POST["emailContact"]);

    $mail -> isHTML(true);
    $mail -> FromName = $_POST["nameContact"];
    $mail -> Subject = $_POST["messageTitle"];
    $mail -> Body = $_POST["message"];

    $mail -> send();

    echo 
    "
    <script>
    alert('Sent success');
    document.location.href = 'contact.php';
    </script>
    ";
    
}

?>