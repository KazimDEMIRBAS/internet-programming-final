
<aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
    <a class="nav-link " href="adminHome.php">
      <i class="bi bi-grid"></i>
      <span>Anasayfa Admin</span>
    </a>
  </li><!-- End Dashboard Nav -->

  <!-- End Forms Nav -->

<!-- End Charts Nav -->



  <li class="nav-heading">Sayfalar</li>
  <li class="nav-item">
    <a class="nav-link collapsed" href="aboutAdmin.php">
      <i class="bi bi-file-earmark"></i>
      <span>Hakkımızda</span>
      </a>
  </li><!-- End Error 404 Page Nav -->

  <li class="nav-item">
    <a class="nav-link collapsed" href="clientAdmin.php">
      <i class="bi bi-dash-circle"></i>
      <span>Müşterilerimiz</span>
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link collapsed" href="pages-error-404.php">
      <i class="bi bi-dash-circle"></i>
      <span>Error 404</span>
    </a>
  </li><!-- End Error 404 Page Nav -->

  <li class="nav-item">
    <a class="nav-link collapsed" href="pages-blank.php">
      <i class="bi bi-file-earmark"></i>
      <span>Blank</span>
    </a>
  </li><!-- End Blank Page Nav -->

</ul>

</aside><!-- End Sidebar-->